from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)


# Load models and scalers
try:
    initial_phase_model = joblib.load('random_forest_model_initial_phase.pkl')
    scaler_initial_phase = joblib.load('scaler_initial_phase.pkl')
    second_phase_model = joblib.load('random_forest_model_second_phase.pkl')
    scaler_second_phase = joblib.load('scaler_second_phase.pkl')
    model_features_initial = joblib.load('feature_names_initial_phase.pkl')
    model_features_second = joblib.load('feature_names_second_phase.pkl')
    print("Models and scalers loaded successfully")
except Exception as e:
    print(f"Error loading models and scalers: {e}")

# Function to preprocess and predict
def process_and_predict(patient_data, model, scaler, model_features):
    try:
        if patient_data.empty:
            raise ValueError("Patient data is empty or not found")

        # Preprocess data for prediction
        patient_features = patient_data.drop(['Name', 'Patient ID', 'Outcome', 'Observations'], axis=1)
        patient_features_encoded = pd.get_dummies(patient_features)
        patient_features_aligned = patient_features_encoded.reindex(columns=model_features, fill_value=0)
        patient_features_scaled = scaler.transform(patient_features_aligned)
        
        # Predict using the model
        prediction = model.predict(patient_features_scaled)[0]

        return prediction
    except Exception as e:
        app.logger.error(f"Error during prediction: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from the request
        request_data = request.get_json()
        app.logger.info(f"Request data received: {request_data}")

        # Extract input data
        patient_name = request_data.get('PatientName', '').strip()
        action = request_data.get('Action', '').strip()

        if not patient_name:
            return jsonify({'error': 'Patient Name not specified'}), 400

        if action not in ['initial', 'second', 'compare']:
            return jsonify({'error': 'Invalid action specified'}), 400

        # Load datasets
        df_initial = pd.read_csv("initial_phase_dataset.csv")
        df_second = pd.read_csv("second_phase_dataset.csv")

        # Find patient in datasets
        patient_data_initial = df_initial[df_initial['Name'].str.strip() == patient_name]
        patient_data_second = df_second[df_second['Name'].str.strip() == patient_name]

        app.logger.info(f"Initial Phase Patient Data: {patient_data_initial}")
        app.logger.info(f"Second Phase Patient Data: {patient_data_second}")

        results = {}

        # Perform predictions based on action
        if action == 'initial':
            initial_phase_prediction = process_and_predict(patient_data_initial, initial_phase_model, scaler_initial_phase, model_features_initial)
            if initial_phase_prediction is not None:
                results['initial_phase_prediction'] = 'Stable' if initial_phase_prediction == 0 else 'Improved' if initial_phase_prediction == 1 else 'Deteriorated'
                results['disorder'] = patient_data_initial.iloc[0]['Disorder']  # Include disorder information
                results['dosage_stage'] = patient_data_initial.iloc[0]['Dosage Stage']  # Include dosage stage information
            else:
                app.logger.error("Error during initial phase prediction")
                return jsonify({'error': 'Error during initial phase prediction'}), 500

        if action == 'second':
            second_phase_prediction = process_and_predict(patient_data_second, second_phase_model, scaler_second_phase, model_features_second)
            if second_phase_prediction is not None:
                results['second_phase_prediction'] = 'Stable' if second_phase_prediction == 0 else 'Improved' if second_phase_prediction == 1 else 'Deteriorated'
                results['disorder'] = patient_data_second.iloc[0]['Disorder']  # Include disorder information
                results['dosage_stage'] = patient_data_second.iloc[0]['Dosage Stage']  # Include dosage stage information
            else:
                app.logger.error("Error during second phase prediction")
                return jsonify({'error': 'Error during second phase prediction'}), 500

        if action == 'compare':
            initial_phase_prediction = process_and_predict(patient_data_initial, initial_phase_model, scaler_initial_phase, model_features_initial)
            second_phase_prediction = process_and_predict(patient_data_second, second_phase_model, scaler_second_phase, model_features_second)

            if initial_phase_prediction is not None and second_phase_prediction is not None:
                results['initial_phase_prediction'] = 'Stable' if initial_phase_prediction == 0 else 'Improved' if initial_phase_prediction == 1 else 'Deteriorated'
                results['second_phase_prediction'] = 'Stable' if second_phase_prediction == 0 else 'Improved' if second_phase_prediction == 1 else 'Deteriorated'

                if initial_phase_prediction == second_phase_prediction:
                    results['comparison_result'] = 'Stable'
                elif initial_phase_prediction > second_phase_prediction:
                    results['comparison_result'] = 'Improved'
                else:
                    results['comparison_result'] = 'Deteriorated'
                
                results['disorder'] = patient_data_initial.iloc[0]['Disorder']  # Include disorder information
                results['dosage_stage'] = patient_data_initial.iloc[0]['Dosage Stage']  # Include dosage stage information
            else:
                app.logger.error("Error during compare prediction")
                return jsonify({'error': 'Error during prediction'}), 500

        app.logger.info(f"Results before sending response: {results}")
        return jsonify(results), 200

    except Exception as e:
        app.logger.error(f"Prediction error: {e}")
        return jsonify({'error': f'An error occurred during prediction: {e}'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
